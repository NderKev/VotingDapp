
ProposalList.insert({ proposalName : VotingSystem.callGetProposals(0), proposalCreationT : VotingSystem.callIpollCreationTime(0).toNumber(), votingDeadLine : VotingSystem.callIvotingDeadline(0).toNumber(), totalVotes : VotingSystem.callInumberOfVotes(0).toNumber(), proposalSupport : VotingSystem.callIcurrentResult(0).toNumber(), proposalExecutionT : VotingSystem.callIpollExecutionTime(0).toNumber(), proposalOutcome : VotingSystem.callGetBallot(0)
})






