/**
Template Controllers

@module Routes
*/

/**
The app routes

@class App routes
@constructor
*/

// Change the URLS to use #! instead of real paths
// Iron.Location.configure({useHashPaths: true});

// Router defaults
Router.configure({
    layoutTemplate: 'layout_main',
    notFoundTemplate: 'layout_notFound',
    yieldRegions: {
        'layout_header': {to: 'header'}
        , 'layout_footer': {to: 'footer'}
    }
});

// ROUTES

/**
The receive route, showing the wallet overview

@method dashboard
*/

// Default route
Router.route('/', {
    template: 'components_unlockAccount',
    name: 'home'
});

// Route for view1
Router.route('/systemInfo', {
    template: 'views_systemInfo',
    name: 'systemInfo'
});

// Route for view2

Router.route('/voterproposals', {
    template: 'views_voterproposals',
    name: 'voterproposals'
});
Router.route('/voterregistry', {
    template: 'views_voterregistry',
    name: 'voterregistry'
});
Router.route('/votersettings', {
    template: 'views_votersettings',
    name: 'votersettings'
});
Router.route('/membership', {
    template: 'components_requestRegistration',
    name: 'membership'
});
Router.route('/unlockAccount', {
    template: 'components_unlockAccount',
     name: 'unlockAccount'
});
Router.route('/electionsettings', {
    template: 'views_electionsettings',
     name: 'ElectionSetUp'
});
Router.route('/electiondetails', {
    template: 'views_electionsdetails',
     name: 'CreateElection'
});