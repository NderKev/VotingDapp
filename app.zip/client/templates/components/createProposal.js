Template["components_createProposal"].onRendered(function(){
	var currentProposalIndex = VotingSystem.numProposals().toNumber();
	//if (currentProposalIndex > 0)
	//{
	//currentProposalIndex = currentProposalIndex -1;	
	//}
	Session.set("index", currentProposalIndex);
});

// template events
Template['components_createProposal'].events({
	'submit form': function(e) {
     e.preventDefault();
	 
	 //var currentProposal = previousProposal+1;
	 
	 
	 //var currentRegistrar= web3.eth.accounts[6];
	 var NewProposal = $('#form-reg-createProposal-propDesc').val();
	 VotingSystem.callNewProposal(NewProposal, {from : web3.eth.accounts[1], gas : 2000000});
	 //var numProposal == VotingSystem.numProposals().toNumber()
	 //var  
	 var curPropIndex= $('#form-reg-createProposal-propIndex').val();
	 //for(i=proposalNow; i>=0; i--){
	//var currentProposal = curPropIndex;
		 //alert(currentProposalIndex);
	 //var minerState = web3.eth.getTransactionRecipt();
	 for (counter= curPropIndex; counter>= 0; counter--)
	 {
     var pName = VotingSystem.callGetProposals(counter);
	 //alert(pName);
	 var pCreateTm = VotingSystem.proposalpollCreationTime(counter).toNumber();
	 var voteEnd = VotingSystem.proposalVotingDeadline(counter).toNumber();
	 var allVotes = VotingSystem.proposalnumberOfVotes(counter).toNumber();
	 var pSupport = VotingSystem.proposalcurrentResult(counter).toNumber();
	 var pExecTime = VotingSystem.proposalpollExecutionTime(counter).toNumber();
	 var pExecutor = VotingSystem.pollExecutor(counter);
	 var pExecuted = VotingSystem.pollExecuted(counter);
	 var pOutcome = VotingSystem.proposalPassed(counter);
	 var PollCreator = VotingSystem.pollCreator(counter);
	 var RemainingMinutes = VotingSystem.proposalDeadlineTime(counter).toNumber();
	 VotingProposals.insert({ proposalName : pName , proposalID : counter, pollCreator : PollCreator, proposalCreationT : pCreateTm, votingDeadLine : voteEnd, totalVotes : allVotes, proposalSupport : pSupport, proposalExecutionT : pExecTime , proposalExecutor : pExecutor , proposalExecuted : pExecuted , proposalOutcome : pOutcome, remainingMinutes : RemainingMinutes });
	 LoggedProposals.insert({ proposalName : pName , proposalIndex : counter});
	}
	 VotedProposals.insert({
		proposal:NewProposal,
		proposalIndex:curPropIndex,
		date : new Date(),
	}, function(error) {
         if (error) {
            console.log("Error: " + error.reason);
         } else {
            alert("The new Proposal is  " + NewProposal);
			$('#form-reg-createProposal-propDesc').val()="";
         } 
	 });
	},
	});
	
	Template['components_createProposal'].helpers({
    /**
    Get The Original Balance

    @method (watchBalance)
    */

    'proposalIndex': function(){        
		return Session.get('index');
    },
});