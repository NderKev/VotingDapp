Template["components_setElectionRule"].onRendered(function(){
});

// template events
Template['components_setElectionRule'].events({
	'submit form': function(e) {
     e.preventDefault();
	 //var currentRegistrar= web3.eth.accounts[6];
	 var VotePeriod = $('#form-reg-setElectionRule-votePeriod').val();
	 //var votePeriod = $('#form-reg-setVotingRules-votePeriod').val();
	 //var winMargin = $('#form-reg-setVotingRules-winMargin').val();
	 VotingSystem.setElectionRules(votePeriod, {from : web3.eth.accounts[1], gas : 2000000});
	 ElectionRules.insert({
		minimumVoters:MinVoters,
		votingPeriod:votePeriod,
		winningMargin:winMargin,
		date : new Date(),
	}, function(error) {
         if (error) {
            console.log("Error: " + error.reason);
         } else {
            alert("The new Election  Voting Period of " + votePeriod );
			$('#form-reg-setElectionRule-votePeriod').val()="";
			//$('#form-reg-setVotingRules-votePeriod').val()="";
			//$('#form-reg-setVotingRules-winMargin').val()="";
         } 
	 });
	 },
});

// template handlebar helper methods
Template['components_setElectionRule'].helpers({
	
});