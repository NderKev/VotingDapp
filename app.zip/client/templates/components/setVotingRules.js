Template["components_setVotingRules"].onRendered(function(){
});

// template events
Template['components_setVotingRules'].events({
	'submit form': function(e) {
     e.preventDefault();
	 //var currentRegistrar= web3.eth.accounts[6];
	 var MinVoters = $('#form-reg-setVotingRules-minVoters').val();
	 var votePeriod = $('#form-reg-setVotingRules-votePeriod').val();
	 var winMargin = $('#form-reg-setVotingRules-winMargin').val();
	 VotingSystem.callChangeVotingRules(MinVoters, votePeriod, winMargin, {from : web3.eth.accounts[1], gas : 2000000});
	 VoteRules.insert({
		minimumVoters:MinVoters,
		votingPeriod:votePeriod,
		winningMargin:winMargin,
		date : new Date(),
	}, function(error) {
         if (error) {
            console.log("Error: " + error.reason);
         } else {
            alert("The new Voting rules are minimum Voters of  " + MinVoters + "  Voting Period of " + votePeriod + " and winning margin of " + winMargin);
			$('#form-reg-setVotingRules-minVoters').val()="";
			$('#form-reg-setVotingRules-votePeriod').val()="";
			$('#form-reg-setVotingRules-winMargin').val()="";
         } 
	 });
	 },
});

// template handlebar helper methods
Template['components_setVotingRules'].helpers({
	
});