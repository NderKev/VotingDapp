Template["components_switchVoterRegistrar"].onRendered(function(){
});

// template events
Template['components_switchVoterRegistrar'].events({
	'submit form': function(e) {
     e.preventDefault();
	 //var currentRegistrar= web3.eth.accounts[6];
	 var NewRegistrar = $('#form-reg-switchVoterRegistrar-address').val();
	 VotingSystem.callTransferOwnership(NewRegistrar, {from : web3.eth.accounts[1], gas : 2000000});
	 Registrar.insert({
		newRegistrar:NewRegistrar,
		date : new Date(),
	}, function(error) {
         if (error) {
            console.log("Error: " + error.reason);
         } else {
            alert("The new Registrar is  " + NewRegistrar);
			$('#form-reg-switchVoterRegistrar-address').val()="";
         } 
	 });
	 },
});

// template handlebar helper methods
Template['components_switchVoterRegistrar'].helpers({
	
});