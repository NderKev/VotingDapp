if(Meteor.isClient){
// this code only runs on the client
Template.voters.helpers({
	'memberDetailsCount' : function() {
		return RegisteredVoters.find();	
	}	
})
}