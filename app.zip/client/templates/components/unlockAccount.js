//if(Meteor.isClient){
//Template['components_unlockAccount'].onRendered(function() {
//	var [] clientBase = web3.eth.accounts;
//});	
Template['components_unlockAccount'].onRendered({
'allAccounts': function(){
	    //var [] accounts = Session.get('accounts');
		var length = web3.eth.accounts.length;
		// Get dropdown element from DOM
var dropdown = document.getElementById("form-reg-unlockAccount-selectAccnt");
// Loop through the array
for (var i = 0; i < length; ++i) {
    // Append the element to the end of Array list
	var accounts = web3.eth.accounts.[i].toString();
    dropdown[dropdown.length] = new Option(i, accounts[i]);
}
	},
});
//}
//Template['components_unlockAccount'].helpers({
	
	//$('#form-reg-unlockAccount-address').val() = address;
//});

Template['components_unlockAccount'].events({
	'submit form': function(e) {
     e.preventDefault();
	 var address = $('#form-reg-unlockAccount-selectAccnt').val();
	 var passCode = $('#form-reg-unlockAccount-passphrase').val();
	 var success = web3.eth.personal.unlockAccount(address, passCode);
	 if (!success){
		 alert("You have entered incorrect passphrase! Kindly check and try again");
	 }else {
		 web3.eth.defaultAccount = address;
		 //$('#form-reg-unlockAccount-address').val() = address;
	 }
	 },
	 
});
