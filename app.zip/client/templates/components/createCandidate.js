Template["components_createCandidate"].onRendered(function(){
	var currentProposalIndex = VotingSystem.electionNumberOfCandidates().toNumber();
	//if (currentProposalIndex > 0)
	//{
	//currentProposalIndex = currentProposalIndex -1;	
	//}
	Session.set("index", currentProposalIndex);
});

// template events
Template['components_createCandidate'].events({
	'submit form': function(e) {
     e.preventDefault();
	 
	 //var currentProposal = previousProposal+1;
	 
	 
	 //var currentRegistrar= web3.eth.accounts[6];
	 var NewCandidate = $('#form-reg-createCandidate-elecDesc').val();
	 //VotingSystem.callNewProposal(NewProposal, {from : web3.eth.accounts[1], gas : 2000000});
	 //var numProposal == VotingSystem.numProposals().toNumber()
	 //var  
	 var CandidateAddress = $('#form-reg-createCandidate-elecIndex').val();
	 //for(i=proposalNow; i>=0; i--){
	//var currentProposal = curPropIndex;
		 //alert(currentProposalIndex);
	 //var minerState = web3.eth.getTransactionRecipt();
	 VotingSystem.registerCandidate(NewCandidate, CandidateAddress, {from : web3.eth.accounts[1], gas : 2000000});
	 CandidateList.insert({
		candidateName:NewCandidate,
		candidateAddress:CandidateAddress,
		date : new Date(),
	}, function(error) {
         if (error) {
            console.log("Error: " + error.reason);
         } else {
            alert("The new Proposal is  " + NewProposal);
			$('#form-reg-createProposal-propDesc').val()="";
         } 
	 });
	},
	});
	
	Template['components_createCandidate'].helpers({
    /**
    Get The Original Balance

    @method (watchBalance)
    */

    'candidateIndex': function(){        
		return Session.get('index');
    },
});