Template["components_eVote"].onRendered(function(){
	//var proposal_ID = VotingSystem.);
	//var thisProposalIndex = VotingSystem.numProposals().toNumber();
	//if (currentProposalIndex > 0)
	//{
	//currentProposalIndex = currentProposalIndex -1;	
	//}
	//Session.set("proposalIndex", thisProposalIndex);
});

// template events
Template['components_eVote'].events({
	'submit form': function(e) {
     e.preventDefault();
	 //var currentRegistrar= web3.eth.accounts[6];
	 var supports;
	 var propID = $('#form-reg-eVote-candidateID').val();
	 var justfText = $('#form-reg-eVote-verrText').val();
	 VotingSystem.callExecuteProposal(propID, {from : web3.eth.accounts[1], gas : 2000000});
	 VotingSystem.callVote(propID, supports, justfText, {from : web3.eth.accounts[1], gas : 2000000});
	 var currentProposal = $('#form-reg-eVote-candidateID').val();
	 var curPropIndex = $('#form-reg-eVote-candidateID').val();
	 VotedCandidates.update(currentProposal,{  totalVotes : VotingSystem.callInumberOfVotes(currentProposal).toNumber(), proposalSupport : VotingSystem.callIcurrentResult(currentProposal).toNumber(), proposalOutcome : VotingSystem.callGetBallot(counter)});
	 TotalVotesCandidates.insert({
		candidateID:propID,
		justificationText:justfText,
		votedBy:web3.eth.accounts[1],
		date : new Date(),
	}, function(error) {
         if (error) {
            console.log("Error: " + error.reason);
         } else {
            alert("The new Votes is to Candidate " + propID + " and Justification Text " + justfText);
			$('#form-reg-eVote-propID').val()="";
			//$('#form-reg-setVotingRules-votePeriod').val()="";
			$('#form-reg-eVote-verrText').val()="";
         } 
	 });
	 },
});

// template handlebar helper methods
Template['components_eVote'].helpers({
	'candidateIDNo': function(){        
		return VotedCandidates.find();
    },
	
	
});