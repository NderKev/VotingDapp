Template["components_registerVoter"].onRendered(function(){
	var currentVoterIndex = VotingSystem.RegisteredVoters().toNumber();
	//if (currentProposalIndex > 0)
	//{
	//currentProposalIndex = currentProposalIndex -1;	
	//}
	Session.set("index", currentVoterIndex);
});

// template events
Template['components_registerVoter'].events({
	'submit form': function(e) {
     e.preventDefault();
	 //var currentRegistrar= web3.eth.accounts[6];
	 // enabled;
	 var NewVoter = $('#form-reg-registerVoter-address').val();
	  var NewVoterName = $('#form-reg-registerVoter-name').val();
	  var enabled = new Boolean(true);
	 VotingSystem.callChangeMembership(NewVoter, enabled, NewVoterName, {from : web3.eth.accounts[1], gas : 2000000});
	 var curVoterIndex = Session.get('index');
	 for (counter= 1; counter<= curVoterIndex; counter++)
	 {
     var memberDetails = VotingSystem.callViewVoter(counter);
	 //if (counter = 0)
		 
	 //alert(pName);
	 RegisteredVoters.insert({ MemberID:counter , MemberDetails : memberDetails })
	}
	 //();
	 VoterRegister.insert({
		voteraddress:NewVoter,
		votername:NewVoterName,
		date : new Date(),
	}, function(error) {
         if (error) {
            console.log("Error: " + error.reason);
         } else {
            alert("The new Voter is " + NewVoterName);
			$('#form-reg-registerVoter-address').val()="";
			$('#form-reg-registerVoter-name').val()="";
         } 
	 });
	},
});

// template handlebar helper methods
Template['components_registerVoter'].helpers({
	
});