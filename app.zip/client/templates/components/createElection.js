Template["components_createElection"].onRendered(function(){
	var currentProposalIndex = VotingSystem.numElections().toNumber();
	//if (currentProposalIndex > 0)
	//{
	//currentProposalIndex = currentProposalIndex -1;	
	//}
	Session.set("index", currentProposalIndex);
});

// template events
Template['components_createElection'].events({
	'submit form': function(e) {
     e.preventDefault();
	 
	 //var currentProposal = previousProposal+1;
	 
	 
	 //var currentRegistrar= web3.eth.accounts[6];
	 var NewProposal = $('#form-reg-createElection-elecDesc').val();
	 VotingSystem.createElection(NewProposal, {from : web3.eth.accounts[1], gas : 2000000});
	 //var numProposal == VotingSystem.numProposals().toNumber()
	 //var  
	 var curPropIndex= $('#form-reg-createElection-elecIndex').val();
	 //for(i=proposalNow; i>=0; i--){
	//var currentProposal = curPropIndex;
		 //alert(currentProposalIndex);
	 //var minerState = web3.eth.getTransactionRecipt();
	 for (counter= curPropIndex; counter>= 0; counter--)
	 {
     var pName = VotingSystem.callGetProposals(counter);
	 //alert(pName);
	 var pCreateTm = VotingSystem.electionpollCreationTime(counter).toNumber();
	 var voteEnd = VotingSystem.electionVotingDeadline(counter).toNumber();
	 var allVotes = VotingSystem.electionNumberOfVoters(counter).toNumber();
	 var pSupport = VotingSystem.electionLeadingCandidate(counter).toNumber();
	 var pExecTime = VotingSystem.electionpollExecutionTime(counter).toNumber();
	 var pExecutor = VotingSystem.electionExecutor(counter);
	 var pExecuted = VotingSystem.electionExecuted(counter);
	 var pOutcome = VotingSystem.electionWinningCandidate(counter);
	 var PollCreator = VotingSystem.electionCreator(counter);
	 var RemainingMinutes = VotingSystem.electionDeadlineTime(counter).toNumber();
	 VotedCandidates.insert({ electionName : pName , electionID : counter, electionCreator : PollCreator, electionCreationT : pCreateTm, electionvotingDeadLine : voteEnd, totalVotes : allVotes, electionSupport : pSupport, electionExecutionT : pExecTime , electionExecutor : pExecutor , electionExecuted : pExecuted , electionOutcome : pOutcome, remainingMinutes : RemainingMinutes });
	 //LoggedProposals.insert({ electionName : pName , electionIndex : counter});
	}
	 VoteCandidate.insert({
		candidateName:NewProposal,
		candidateIndex:curPropIndex,
		date : new Date(),
	}, function(error) {
         if (error) {
            console.log("Error: " + error.reason);
         } else {
            alert("The new Candidate is  " + NewProposal);
			$('#form-reg-createElection-elecDesc').val()="";
         } 
	 });
	},
	});
	
	Template['components_createElection'].helpers({
    /**
    Get The Original Balance

    @method (watchBalance)
    */

    'electionIndex': function(){        
		return Session.get('index');
    },
});