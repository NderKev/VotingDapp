Template['components_requestRegistration'].events({
	'submit form': function(e) {
     e.preventDefault();
	 //var currentRegistrar= web3.eth.accounts[6];
	 // enabled;
	 var clientEmail = $('#form-reg-requestRegistration-voterEmail').val();
	  var clientPhone = $('#form-reg-requestRegistration-clientTel').val();
	  
	 ClientContacts.insert({
		email:clientEmail,
		telephone:clientPhone,
		date : new Date(),
	}, function(error) {
         if (error) {
            console.log("Error: " + error.reason);
         } else {
            alert("Your Request has been sent, Kindly await email confirmation ");
			$('#form-reg-requestRegistration-voterEmail').val()="";
			$('#form-reg-requestRegistration-clientEmail').val()="";
         } 
	 });
	},
});