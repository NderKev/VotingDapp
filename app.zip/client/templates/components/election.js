if(Meteor.isClient){
// this code only runs on the client
Template.election.helpers({
	'electionCount' : function() {
		return VotedCandidates.find();	
	}	
})
}
Template['election'].events({
	'#btn-vote.click': function(e) {
     e.preventDefault();
	 //var currentRegistrar= web3.eth.accounts[6];
	 //var NewRegistrar = $('#form-reg-switchVoterRegistrar-address').val();
	    //opener.parent.frames['main'].location.href="vote.html";
		var popWin = window.open("eVote.html");
		//self.close();
		//Router.go('walletprofile');
	 },
});