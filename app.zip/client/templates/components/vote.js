Template["components_vote"].onRendered(function(){
	//var proposal_ID = VotingSystem.);
	//var thisProposalIndex = VotingSystem.numProposals().toNumber();
	//if (currentProposalIndex > 0)
	//{
	//currentProposalIndex = currentProposalIndex -1;	
	//}
	//Session.set("proposalIndex", thisProposalIndex);
});

// template events
Template['components_vote'].events({
	'submit form': function(e) {
     e.preventDefault();
	 //var currentRegistrar= web3.eth.accounts[6];
	 var supports;
	 var propID = $('#form-reg-vote-propID').val();
	 var voteChoice = $('#form-reg-vote-choice').val();
	 if (voteChoice=="For")
	 {
		supports = new Boolean(true);
	 } else{
		 supports = new Boolean(false);
	 }
	 var justfText = $('#form-reg-vote-justText').val();
	 VotingSystem.callExecuteProposal(propID, {from : web3.eth.accounts[1], gas : 2000000});
	 VotingSystem.callVote(propID, supports, justfText, {from : web3.eth.accounts[1], gas : 2000000});
	 var currentProposal = $('#form-reg-vote-propID').val();
	 var curPropIndex = $('#form-reg-vote-propID').val();
	 ProposalList.update(currentProposal,{  totalVotes : VotingSystem.callInumberOfVotes(currentProposal).toNumber(), proposalSupport : VotingSystem.callIcurrentResult(currentProposal).toNumber(), proposalOutcome : VotingSystem.callGetBallot(counter)});
	 TotalVotes.insert({
		proposalID:propID,
		choice:voteChoice,
		justificationText:justfText,
		votedBy:web3.eth.accounts[1],
		date : new Date(),
	}, function(error) {
         if (error) {
            console.log("Error: " + error.reason);
         } else {
            alert("The new Votes is to ProposalID " + propID + " Choice " + voteChoice + " and Justification Text " + justfText);
			$('#form-reg-vote-propID').val()="";
			//$('#form-reg-setVotingRules-votePeriod').val()="";
			$('#form-reg-vote-justText').val()="";
         } 
	 });
	 },
});

// template handlebar helper methods
Template['components_vote'].helpers({
	'proposalIDnum': function(){        
		return LoggedProposals.find();
    },
	
	
});