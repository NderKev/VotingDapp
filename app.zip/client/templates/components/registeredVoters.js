if(Meteor.isClient){
// this code only runs on the client
Template.registeredVoters.helpers({
	'voterReg' : function() {
		return VoterList.find()	
	}	
})
}