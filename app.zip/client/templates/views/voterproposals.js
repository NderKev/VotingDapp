Template['views_voterproposals'].helpers({
    /**
    Get the name

    @method (name)
    */

    'name': function(){
        return this.name || TAPi18n.__('dapp.voterproposals.defaultName');
    }
});

// When the template is created
Template['views_voterproposals'].onCreated(function(){
	Meta.setSuffix(TAPi18n.__("dapp.voterproposals.title"));
});