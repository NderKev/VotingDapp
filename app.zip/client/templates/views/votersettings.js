Template['views_votersettings'].helpers({
    /**
    Get the name

    @method (name)
    */

    'name': function(){
        return this.name || TAPi18n.__('dapp.votersettings.defaultName');
    }
});

// When the template is created
Template['views_votersettings'].onCreated(function(){
	Meta.setSuffix(TAPi18n.__("dapp.votersettings.title"));
});