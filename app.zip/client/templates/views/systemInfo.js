/**
Template Controllers

@module Templates
*/

/**
The view1 template

@class [template] views_view1
@constructor
*/

Template['views_systemInfo'].helpers({
    /**
    Get the name

    @method (name)
    */

    'name': function(){
        return this.name || TAPi18n.__('dapp.systemInfo.defaultName');
    }
});

// When the template is created
Template['views_systemInfo'].onCreated(function(){
	Meta.setSuffix(TAPi18n.__("dapp.systemInfo.title"));
});
